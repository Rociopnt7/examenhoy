package alumnos;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.TreeMap;

public class Asignaturas {
	private TreeMap<String, Notas> listaAsignaturas = new TreeMap<>();

	public Asignaturas() {
	}
	
	
	//añadir asignaturas al treemap por nombre
	public void anyadirAsignatura(Notas n) {
		//guardar el par clave-valor, la clave es el nombre de n
	}
	//listar informacion de todas las asignaturas
	public String infoAsignaturas() {
		String info = "Listado de asignaturas: \n";
		
		//usando un for each, recorrer los valores y construir la cadena info
		//usar los metodos de la clase notas
		
		return info;
	}
	//listar notas medias de las asignaturas
	public String infoMedias() {
		String info = "Listado de notas medias: \n";
	
		//usando un for each, recorrer los valores y construir la cadena info
		//usar los metodos apropiados de la clase Notas
		
		return info;
	}
	
	//listar asignaturas suspendidas
	public String infoSuspendidas() {
		String info = "Listado de asignaturas suspensas: \n";
		
		// Usar un for each, una asignatura se considera suspensa si su media es < 5.0
		
		return info;
	}
	
	//generar informe en un archivo
	public void generarInforme() {
		File fichero = new File("./src/alumnos/informe.txt");

		try {
			FileWriter fw = new FileWriter(fichero, true);
			BufferedWriter w = new BufferedWriter(fw);
			w.write("Informe de las asignaturas: \n");
			
			//escribir la informacion generada por los metodos al fichero 
			
			w.close();
			

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
}
